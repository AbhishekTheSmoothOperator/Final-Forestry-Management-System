package com.cg.fms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.fms.entity.Land;

public interface LandDao extends JpaRepository<Land, String>{

}
package com.cg.fms.entity;

public enum UserType {
	ADMIN,CUSTOMER;
}

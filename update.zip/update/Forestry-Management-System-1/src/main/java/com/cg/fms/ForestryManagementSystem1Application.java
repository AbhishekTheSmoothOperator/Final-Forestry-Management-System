package com.cg.fms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForestryManagementSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(ForestryManagementSystem1Application.class, args);
	}

}

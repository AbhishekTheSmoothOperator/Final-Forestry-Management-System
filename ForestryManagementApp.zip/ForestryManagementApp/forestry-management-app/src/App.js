import logo from './logo.svg';
import './App.css';
import ProfileCard from './Component/profile card';
import Routes from './Route';
import updatecustomer from './Component/updatecustomer';





function App() {
  return (
    <div >
      <Routes/>
      {/* <Basic/> */}
      {/* <CounterComponent/> */}
      {/* <ProfileCard/> */}
      {/* <updatecustomer/> */}
     
    </div>
  );
}

export default App;
